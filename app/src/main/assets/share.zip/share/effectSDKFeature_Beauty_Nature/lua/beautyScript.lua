local exports = exports or {}
local beautyScript = {}
beautyScript.__index = beautyScript

function beautyScript.new(construct, ...)
    local self = setmetatable({}, beautyScript)
    self.smoothMaterial = nil
    if construct and beautyScript.constructor then beautyScript.constructor(self, ...) end
    return self
end



function beautyScript:onStart(comp)
    local scene = comp.entity.scene
    local entities = scene.entities
    local smoothTag = 1
    for i = 0, entities:size() - 1 do
        local entity = entities:get(i)
        if entity:hasTag(smoothTag) then
            local renderer = entity:getComponent("MeshRenderer")
            if renderer ~= nil then
                self.smoothMaterial = renderer.materials:get(0)
                break
            end
        end

    end

end


function beautyScript:onUpdate(comp, deltaTime)

end

function beautyScript:onEvent(comp, event)
    -- print("event.type = " .. event.type .. ", event.name: " .. event.args:get(0) .. ", event.key: " .. event.args:get(1) .. ", event.value: " ..  event.args:get(2))
    if event.args:get(0) == "SetEffectIntensity" and event.args:get(1) == "Internal_Beauty" then
        -- 设置磨皮程度
        self.smoothMaterial.properties:setFloat("smooth", event.args:get(2))
    end
end

exports.beautyScript = beautyScript

return exports
